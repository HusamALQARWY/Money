package com.daftarsiyanat.app;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import org.json.JSONObject;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    WebView web;
    static final String CHANNEL = "maintenance_reminders";
    static final String PREFS = "maintenance_alarm_schedules";

    ActivityResultLauncher<String> permission = registerForActivityResult(
        new ActivityResultContracts.RequestPermission(),
        ok -> Toast.makeText(this, ok ? "تم السماح بالإشعارات" : "الإشعارات غير مفعلة", Toast.LENGTH_SHORT).show()
    );

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        channel();
        web = new WebView(this);
        setContentView(web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(this), "AndroidNotifications");
        web.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permission.launch(Manifest.permission.POST_NOTIFICATIONS);
        }
    }

    void channel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "تذكيرات الصيانة", NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("تنبيهات الصيانة قبل الموعد وفي يوم الاستحقاق");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    static void scheduleAlarm(Context context, String id, String title, String message, long at) {
        Intent i = new Intent(context, ReminderReceiver.class);
        i.putExtra("title", title);
        i.putExtra("message", message);
        i.putExtra("id", id);
        int req = id.hashCode() & 0x7fffffff;
        PendingIntent p = PendingIntent.getBroadcast(context, req, i,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        AlarmManager am = (AlarmManager) context.getSystemService(ALARM_SERVICE);
        if (am != null) {
            long when = Math.max(System.currentTimeMillis() + 5000, at);
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, p);
            else am.set(AlarmManager.RTC_WAKEUP, when, p);
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    public static class Bridge {
        private final MainActivity a;
        Bridge(MainActivity x) { a = x; }

        @JavascriptInterface public void schedule(String id, String title, String message, long at) {
            if (id == null || id.trim().isEmpty() || at <= System.currentTimeMillis()) return;
            try {
                JSONObject item = new JSONObject();
                item.put("id", id); item.put("title", title); item.put("message", message); item.put("at", at);
                a.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("schedule:" + id, item.toString()).apply();
                scheduleAlarm(a, id, title, message, at);
            } catch (Exception ignored) { }
        }

        @JavascriptInterface public void cancel(String id) {
            if (id == null) return;
            Intent i = new Intent(a, ReminderReceiver.class);
            PendingIntent p = PendingIntent.getBroadcast(a, id.hashCode() & 0x7fffffff, i,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
            AlarmManager am = (AlarmManager) a.getSystemService(ALARM_SERVICE);
            if (am != null) am.cancel(p);
            a.getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove("schedule:" + id).apply();
        }

        @JavascriptInterface public void openNotificationSettings() {
            Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, a.getPackageName());
            a.startActivity(i);
        }
    }
}
