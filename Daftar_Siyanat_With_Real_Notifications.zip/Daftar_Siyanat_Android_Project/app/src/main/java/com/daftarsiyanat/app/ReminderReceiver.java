package com.daftarsiyanat.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String t = i.getStringExtra("title"), m = i.getStringExtra("message"), id = i.getStringExtra("id");
        String ch = "maintenance_reminders";
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(ch, "تذكيرات الصيانة", NotificationManager.IMPORTANCE_HIGH));
        Intent open = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification n = new NotificationCompat.Builder(c, ch)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle(t == null ? "تذكير صيانة" : t)
            .setContentText(m == null ? "موعد صيانة مركبتك" : m)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(m == null ? "موعد صيانة مركبتك" : m))
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi).build();
        nm.notify(id == null ? (int) System.currentTimeMillis() : (id.hashCode() & 0x7fffffff), n);
        if (id != null) c.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE).edit().remove("schedule:" + id).apply();
    }
}
